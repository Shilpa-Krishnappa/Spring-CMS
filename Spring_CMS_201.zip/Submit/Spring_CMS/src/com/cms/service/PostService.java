package com.cms.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cms.dao.BaseDao;
import com.cms.dao.PostDao;
import com.cms.modal.Post;

@Service
public class PostService extends BaseService<Post> {
	
	@Resource
	private PostDao postDao;
	
	@Override
	public BaseDao<Post> getDao() {
		// TODO Auto-generated method stub
		return postDao;
	}
	
	public Post add(Post entity) {
		return postDao.add(entity);
	}
	
	public Post edit(Post entity){
		return postDao.edit(entity);
	}
	
	public void remove(Post entity){
		postDao.remove(entity);
	}

}
