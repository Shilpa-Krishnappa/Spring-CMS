package com.cms.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cms.dao.BaseDao;
import com.cms.dao.CommentDao;
import com.cms.modal.Comment;

@Service
public class CommentService extends BaseService<Comment> {
	
	@Resource
	private CommentDao commentDao;
	
	@Override
	public BaseDao<Comment> getDao() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public Comment add(Comment entity){
		return commentDao.add(entity);
	}
}
