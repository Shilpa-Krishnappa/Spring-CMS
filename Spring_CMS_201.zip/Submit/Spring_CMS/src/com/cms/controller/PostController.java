package com.cms.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.cms.dao.Page;
import com.cms.modal.Attachment;
import com.cms.modal.Comment;
import com.cms.modal.Post;
import com.cms.modal.Tag;
import com.cms.service.CommentService;
import com.cms.service.PostService;
import com.cms.service.TagService;
import com.cms.util.BlogUtil;

@Controller
@RequestMapping("/article")
public class PostController {
	
	@Resource
	private PostService postService;
	
	@Resource
	private TagService tagService;
	
	@Resource
	private CommentService commentService;
	
	@RequestMapping("/new")
	public String toNew(){	
		return "addArticle";
	}
	
	private String FILE_UPLOADPATH= "D:/uploadcms";
	
	@RequestMapping(value="/new",method = RequestMethod.POST)
	public ModelAndView add(Post post,String note_tags,HttpServletRequest request/*,HttpServletResponse response*/){
		Date date = new Date();
		post.setCreated_at(BlogUtil.parseDate(date));
		String[] strs = note_tags.split(Pattern.quote("|"));
		post = postService.add(post);
		List<Tag> tags = new ArrayList<Tag>();
		for(String str : strs){
			Tag tag = new Tag();
			tag.setName(str);
			tag.setPost(post);
			tag = tagService.add(tag);
			tags.add(tag);
		}
		post.setTags(tags);
		post = postService.edit(post);
		ModelAndView modelandview = new ModelAndView(new RedirectView(request.getContextPath()+"/article/"+post.getPost_id()));
		List<Attachment> attachments = getAttachments(post.getPost_id());
		modelandview.addObject("attachments", attachments);
		return modelandview; 
	}
	
	@RequestMapping("/{id}")
	public String show(@PathVariable("id") int id,ModelMap modelMap){
		Post post = postService.get(id);
		modelMap.addAttribute(post);
		List<Attachment> attachments = getAttachments(id);
		modelMap.addAttribute("attachments", attachments);
		return "showArticle";
	}
	
	@RequestMapping("/{id}/edit")
	public String toEdit(@PathVariable("id") int id,ModelMap modelMap){
		Post post = postService.get(id);
		modelMap.addAttribute(post);
		List<Attachment> attachments = getAttachments(id);
		modelMap.addAttribute("attachments", attachments);
		return "editArticle";
	}
	
	@RequestMapping(value = "/{id}/edit",method = RequestMethod.POST)
	public ModelAndView edit(Post post,HttpServletRequest request/*,HttpServletResponse response*/){
		post.setTags(postService.get(post.getPost_id()).getTags());
		post.setComments(postService.get(post.getPost_id()).getComments());
		Date date = new Date();
		post.setCreated_at(date);
		post = postService.edit(post);
		ModelAndView modelandview = new ModelAndView(new RedirectView(request.getContextPath()+"/article/"+post.getPost_id()));
		List<Attachment> attachments = getAttachments(post.getPost_id());
		modelandview.addObject("attachments", attachments);
		return modelandview; 
	}
	
	@RequestMapping(value="/{id}/remove",method = RequestMethod.GET)
	public String remove(@PathVariable("id") int id,ModelMap modelMap){
		Post post = postService.get(id);
		for(Tag tag : post.getTags()){
			tagService.remove(tag);
		}
		for(Comment comment : post.getComments()){
			commentService.remove(comment);
		}
		postService.remove(post);
		Page page = postService.pagedQuery("from Post", 1, 10);
		List<Post> posts = page.getResult();
		modelMap.addAttribute("posts",posts);
		return "index";
	}
	
	@RequestMapping(value = "/{id}/upload",method = RequestMethod.POST)
	public ModelAndView upload(@RequestParam("fileInRequest") CommonsMultipartFile  fileInRequest,HttpServletRequest request/*,HttpServletResponse response*/){
		
		int id = Integer.parseInt(request.getParameter("id"));
			String fileName="";

			if(fileInRequest!=null){
				fileName = fileInRequest.getOriginalFilename();
				FileOutputStream outputStream = null;
				
				String filePath = getFileUploadPath() + "/" + id;
				
				File file = new File(filePath);
				if(!file.exists()){
					file.mkdirs();
				}
				
				filePath += "/" + fileInRequest.getOriginalFilename();
				
	            try {
	                outputStream = new FileOutputStream(new File(filePath));
	                outputStream.write(fileInRequest.getBytes());
	                outputStream.close();
	            } catch (Exception e) {
	                System.out.println("Error while saving file");
	            }
			
		}
		
		Post post = postService.get(id);
		ModelAndView modelandview = new ModelAndView(new RedirectView(request.getContextPath()+"/article/"+post.getPost_id()+"/edit"));
		List<Attachment> attachments = getAttachments(post.getPost_id());
		modelandview.addObject("attachments", attachments);
		return modelandview; 
	}
	
	@RequestMapping(value = "/getfileview/{id}/{filename}/view", method = RequestMethod.GET)
	public void getFileView(@PathVariable("id") int id, @PathVariable("filename") String filename, ModelMap modelMap, HttpServletResponse response){
		File file = getFile(id, filename);
		if(file!=null){
			response.setContentType("image/jpeg");
			ServletOutputStream responseOutputStream;
			try {
				 FileInputStream fis = new FileInputStream(file);
		         BufferedInputStream bis = new BufferedInputStream(fis);             
		         BufferedOutputStream output = new BufferedOutputStream(response.getOutputStream());
		         for (int data; (data = bis.read()) > -1;) {
		           output.write(data);
		         } 
		         output.flush();
		         bis.close();
		         output.close();
		         fis.close();
		         
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	@RequestMapping(value = "/getfiledl/{id}/{filename}/dl", method = RequestMethod.GET)
	public void getFileDl(@PathVariable("id") int id, @PathVariable("filename") String filename, ModelMap modelMap, HttpServletResponse response){
		File file = getFile(id, filename);
		if(file!=null){
			try {
				response.setContentType("application/octet-stream");
				response.setContentLength((int) file.length());
				response.setHeader( "Content-Disposition",
				         String.format("attachment; filename=\"%s\"", file.getName()));
				OutputStream out = response.getOutputStream();
				try (FileInputStream in = new FileInputStream(file)) {
				    byte[] buffer = new byte[4096];
				    int length;
				    while ((length = in.read(buffer)) > 0) {
				        out.write(buffer, 0, length);
				    }
				}
				out.flush();
		         
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	@RequestMapping(value = "/delfile/{id}/{filename}/del", method = RequestMethod.GET)
	public ModelAndView delFile(@PathVariable("id") int id, @PathVariable("filename") String filename, ModelMap modelMap, HttpServletRequest request){
		File file = getFile(id, filename);
		if(file!=null){
			file.delete();
		}
		Post post = postService.get(id);
		ModelAndView modelandview = new ModelAndView(new RedirectView(request.getContextPath()+"/article/"+post.getPost_id()+"/edit"));
		List<Attachment> attachments = getAttachments(post.getPost_id());
		modelandview.addObject("attachments", attachments);
		return modelandview; 
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/load")
	public @ResponseBody List<Post> loadMore(@RequestParam("pageNo") int pageNo){
		System.out.println(pageNo);
		Page page = postService.pagedQuery("from Post", pageNo+1, 10);
		List<Post> posts = page.getResult();
		System.out.println(posts.size());
		return posts;
	}
	
	

	public PostService getPostService() {
		return postService;
	}

	public void setPostService(PostService postService) {
		this.postService = postService;
	}

	public TagService getTagService() {
		return tagService;
	}

	public void setTagService(TagService tagService) {
		this.tagService = tagService;
	}
	
	private String getFileUploadPath(){
		File file = new File(FILE_UPLOADPATH);
		if(!file.exists()){
			file.mkdirs();
		}
		return FILE_UPLOADPATH;
	}
	
	private List getAttachments(int id){
		List<Attachment> attachments = new ArrayList<Attachment>();
		File file = new File(FILE_UPLOADPATH+"/"+id);
		if(file.exists()){
			File[] files = file.listFiles();
			for(File file1 : files){
				Attachment attachment = new Attachment();
				attachment.setName(file1.getName());
				attachment.setType(((file1.getName().endsWith("jpg")||file1.getName().endsWith("png")) ? "image" : "other"));
				attachment.setURL("article/getfileview/"+id+"/"+file1.getName()+"/view");
				attachment.setDlURL("article/getfiledl/"+id+"/"+file1.getName()+"/dl");
				attachment.setDelURL("article/delfile/"+id+"/"+file1.getName()+"/del");
				attachments.add(attachment);
			}
		}
		return attachments;
	}
	
	private File getFile(int id, String filename){
		File file = new File(FILE_UPLOADPATH+"/"+id);
		if(file.exists()){
			File[] files = file.listFiles();
			for(File file1 : files){
				if(file1.getName().equalsIgnoreCase(filename)){
					return file1;
				}
			}
		}
		return null;
	}
	
}
